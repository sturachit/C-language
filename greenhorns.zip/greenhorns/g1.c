#include<stdio.h>
void main()
{

    //1)
    printf("\t\t*\t\t*\n");
    printf("\t*\t\t*\n");
    printf("*\t\t*\n");
    printf("\t*\t\t*\n");
    printf("\t\t*\t\t*\n\n\n");

    
   
}