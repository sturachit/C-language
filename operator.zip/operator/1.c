#include <stdio.h>

void main()
{

    // 1)W a p to find size of variable type
    int a1;
    float b1;
    double c1;
    char d1;

    printf("size of int is %d", sizeof(a1));
    printf("\nsize of int is %d", sizeof(b1));
    printf("\nsize of int is %d", sizeof(c1));
    printf("\nsize of int is %d", sizeof(d1));
}