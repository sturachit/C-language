#include <stdio.h>

void main()
{
    //)wap to find below operation using value:

    int a, b, c, d;
    a = 100;
    b = 100;
    c = 10.5;
    d = 100.5;
    printf("\n ++a is %d", ++a);
    printf("\n --b is %d", --b);
    printf("\n ++c is %d", ++c);
    printf("\n --d is %d", --d);
}