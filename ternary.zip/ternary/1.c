#include<stdio.h>

void main(){
    int age,a,b;
    printf("Enter age :\n");
    scanf("%d",&age);
    (age ==18)?printf("u r eligable for vote"):printf("u r not eligable for vote\n");

}