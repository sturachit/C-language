#include<stdio.h>

int main(){
    //1)Wap to display 1 to 10 numbers.
    int i=1;
     while(i<=10){
        printf("%d\n",i);
        i++;
    }
    return 0;
}