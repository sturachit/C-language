#include <stdio.h>

int main() {
    //7)Wap to display reverse 1 to 10 numbers.
    int num = 10;
    while (num >= 1) {
        printf("%d ", num);
        num--;
    }
    printf("\n");
    return 0;
}
